see image capture1.jpg
set as shown to render high reflective materials and glass